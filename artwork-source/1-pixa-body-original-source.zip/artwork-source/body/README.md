# Body vocabulary illustrations

Original vector artwork created for Pixa World, November 2026. No external stock graphics, fonts, or embedded images are used. Each SVG pairs with the same-named lossless WebP in public/card-image/body/.

The highlighted region indicates the named body part. Target-area closeups preserve readability in the existing small mobile choice and matching cards. The tooth and finger include explanatory details. These images fill existing missing file paths; they do not change lesson sequencing, scoring, pronunciation rules, or account access.

To regenerate a WebP with Sharp: read the SVG buffer and call sharp(buffer).webp({lossless:true}).toFile(outputPath).
